import numpy as np
import pandas as pd
from scipy.signal import lfilter, butter, filtfilt
import math
import csv
from control import pade, series, forced_response, bode_plot
from AircraftIden import FreqIdenSIMO
from control import tf as transfer_func
import matplotlib.pyplot as plt
# Load data from CSV files
from AircraftIden.FreqIden import time_seq_preprocess
from control import TransferFunction, bode_plot, bode


def butter_lowpass(cutoff, fs, order=5):
    """
    Design a Butterworth low-pass filter.

    Parameters:
    cutoff (float): The cutoff frequency of the filter.
    fs (float): The sampling frequency of the signal.
    order (int): The order of the filter.

    Returns:
    b, a (ndarray, ndarray): Numerator (b) and denominator (a) coefficients of the filter.
    """
    nyquist = 0.5 * fs
    normal_cutoff = cutoff / nyquist
    b, a = butter(order, normal_cutoff, btype='low', analog=False)
    return b, a

def apply_lowpass_filter(data, cutoff, fs, order=5):
    """
    Apply a low-pass filter to a signal.

    Parameters:
    data (ndarray): The input signal.
    cutoff (float): The cutoff frequency of the filter.
    fs (float): The sampling frequency of the signal.
    order (int): The order of the filter.

    Returns:
    y (ndarray): The filtered signal.
    """
    b, a = butter_lowpass(cutoff, fs, order=order)
    y = filtfilt(b, a, data)
    return y




with open('/home/astik/Downloads/arducopter_sysid_data/bill_sid_axis1_nohead.csv', 'r') as f:
       reader = csv.reader(f)
       data = list(reader)
arr = np.array(data)
arr = np.array(data, dtype=float)
time = arr[:, 1]
u = arr[:, 23]
    #rout_source = arr[:,2]
y = arr[:, 4]*math.pi / 180
resampled_input = time_seq_preprocess(time, u)
resampled_output = time_seq_preprocess(time, y)
# State Variable Filter: Low-pass filter
def state_variable_filter(data, alpha):
    b, a = [alpha], [1, alpha - 1]
    filtered_data = lfilter(b, a, data)
    return filtered_data

# Numerical differentiation
def numerical_diff(data, dt):
    return np.gradient(data, dt)

# Sampling interval (assuming uniform sampling)
dt = np.mean(np.diff(time))

# Apply SVF and calculate derivatives
z0 = apply_lowpass_filter(y, 5, 100)
z1 = numerical_diff(z0, dt)
z2 = numerical_diff(z1, dt)
z3 = numerical_diff(z2, dt)
z4 = numerical_diff(z3, dt)

w0 = apply_lowpass_filter(u, 5, 100)
w1 = numerical_diff(w0, dt)
w2 = numerical_diff(w1, dt)

# Construct Z and W matrices for the system
Z = np.column_stack((z4, z3, z2, z1, z0, -w2))
Z1 = np.column_stack((-z3, -z2, -z1, -z0, w2, w1, w0))
W = w0
W1 = z4

#print(Z.shape)
#print(W.shape)
# Estimate parameters using least squares
theta, _, _, _ = np.linalg.lstsq(Z, W, rcond=None)
theta1,_,_,_ = np.linalg.lstsq(Z1,W1, rcond=None)
# Display estimated parameters
a, b, c, d, e, f = theta
#print(theta)
a1, b1, c1, d1, e1, f1, g1= theta1

num_arr = np.array([0, 0, f, 0, 0])  # f*s^2 term in the numerator
den_arr = np.array([a, b, c, d, e])  # a*s^4 + b*s^3 + c*s^2 + d*s + e in the denominator

num_arr_c = np.array([0, 0, e1, 0, 0])  # f*s^2 term in the numerator
den_arr_c = np.array([1, a1, b1, c1, d1])  # a*s^4 + b*s^3 + c*s^2 + d*s + e in the denominator
print(1/100000,a1/100000,b1/100000,c1/100000,d1/100000,e1/100000, 0.0)
#num_arr_true = [-0.053335891322632833, 0.0, 0.0]
num_arr_true = [-0.15329678815599473, 0, 0] # axis 3
#den_arr_true =  [-2.424051991246246e-05, -0.0002765505151990164, -0.00041529913762616637, 0.0001673805896441195, -0.017578685686513985]
den_arr_true = [9.615955767444341e-05, -0.00783086676486907, -0.020992177255030064, 0.02131053078094972, -0.0686197403226381] # axis 3
# Create the transfer function
sys_tf = TransferFunction(num_arr, den_arr)
sys_tf2 = TransferFunction(num_arr_true,den_arr_true)
sys_tf3 = TransferFunction(num_arr_c,den_arr_c)

# Compute Bode plots for both transfer functions
mag, phase, omega = bode(sys_tf, Plot=False)
mag2, phase2, omega2 = bode(sys_tf2, Plot=False)
mag3, phase3, omega3 = bode(sys_tf3, Plot=False)

# Plot the magnitude responses
plt.figure()
plt.subplot(2, 1, 1)
plt.semilogx(omega, 20 * np.log10(mag), label='Estimated TF')
plt.semilogx(omega2, 20 * np.log10(mag2), label='True TF', linestyle='dashed')
plt.semilogx(omega3, 20 * np.log10(mag3), label='c TF', linestyle='dashed')


plt.title('Bode Plot - Magnitude')
plt.xlabel('Frequency [rad/s]')
plt.ylabel('Magnitude [dB]')
plt.grid(True)
plt.legend()

# Plot the phase responses
plt.subplot(2, 1, 2)
plt.semilogx(omega, np.degrees(phase), label='Estimated TF')
plt.semilogx(omega2, np.degrees(phase2), label='True TF', linestyle='dashed')
plt.semilogx(omega3, np.degrees(phase3), label='c TF', linestyle='dashed')


plt.title('Bode Plot - Phase')
plt.xlabel('Frequency [rad/s]')
plt.ylabel('Phase [degrees]')
plt.grid(True)
plt.legend()

plt.show()
